<?php
define('API_KEY','');
define('API_SECRET','');
define('EMAIL_ID','');
?>